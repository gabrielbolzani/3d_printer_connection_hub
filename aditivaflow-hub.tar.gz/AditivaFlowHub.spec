# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['deployments\\windows\\hub_gui.py'],
    pathex=['.'],
    binaries=[],
    datas=[('templates', 'templates'), ('favicon.ico', '.'), ('favicon-32x32.png', '.')],
    hiddenimports=['app', 'PIL', 'pystray', 'waitress', 'requests'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='AditivaFlowHub',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['favicon.ico'],
)
